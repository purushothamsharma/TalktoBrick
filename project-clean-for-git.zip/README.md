# Brick (BFF) - AI-Powered Restaurant Management Platform

## Rasa Challenge Submission 2025

Brick (BFF - Brick For Food) is a comprehensive restaurant management platform that leverages Rasa Pro and CALM to provide intelligent ordering, dynamic pricing, and operational optimization.

### Core Features

- **Multi-Language Order Management**
  - Natural language processing in English and Spanish
  - Smart menu recommendations
  - Real-time order customization
  - Dietary restrictions handling

- **Dynamic Pricing with AI**
  - Rush hour optimization
  - Demand-based pricing
  - Competitive analysis
  - Revenue maximization

- **Menu and Prep Forecasting**
  - Inventory optimization
  - Weather impact analysis
  - Event-based planning
  - Waste reduction

- **Admin Dashboard**
  - Real-time analytics
  - Staff management
  - Menu performance tracking
  - Customer insights

### Technology Stack

- **Frontend**
  - React with TypeScript
  - Tailwind CSS
  - Framer Motion
  - Recharts

- **Backend**
  - Supabase
  - Edge Functions
  - Real-time subscriptions
  - Row Level Security

- **AI Integration**
  - Rasa Pro for conversational AI
  - CALM for embeddings and recommendations
  - OpenAI fallback for complex queries

### Getting Started

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```

### Environment Setup

Create a `.env` file with the following variables:

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_key
VITE_OPENAI_API_KEY=your_openai_key
VITE_RASA_SERVER_URL=your_rasa_url
VITE_RASA_TOKEN=your_rasa_token
```

### Rasa Pro Setup

1. Install Rasa Pro:
   ```bash
   pip install rasa-pro
   ```

2. Train the model:
   ```bash
   cd rasa-brick
   rasa train
   ```

3. Start Rasa services:
   ```bash
   # Start Rasa server
   rasa run --enable-api --cors "*" --port 5005

   # Start actions server
   rasa run actions
   ```

### Testing

1. Unit Tests:
   ```bash
   npm run test
   ```

2. E2E Tests:
   ```bash
   npm run test:e2e
   ```

3. Rasa Tests:
   ```bash
   cd rasa-brick
   rasa test
   ```

### Deployment

1. Frontend (Netlify):
   ```bash
   npm run build
   ```

2. Rasa (Docker):
   ```bash
   cd rasa-brick
   docker-compose up -d
   ```

3. Edge Functions (Supabase):
   ```bash
   supabase functions deploy
   ```

### API Documentation

#### Edge Functions

1. `chat-completions`:
   - Purpose: Generate chat responses using CALM
   - Method: POST
   - Headers: `Authorization: Bearer <token>`
   - Body: `{ messages: Message[], context: any }`

2. `create-embeddings`:
   - Purpose: Generate embeddings for menu items
   - Method: POST
   - Body: `{ text: string }`

3. `rasa-proxy`:
   - Purpose: Proxy requests to Rasa Pro
   - Method: POST
   - Headers: `Authorization: Bearer <token>`
   - Body: `{ message: string, sender: string, metadata: any }`

#### Rasa Endpoints

1. `/webhooks/rest/webhook`:
   - Purpose: Main chat endpoint
   - Method: POST
   - Headers: `Authorization: Bearer <token>`
   - Body: `{ message: string, sender: string }`

2. `/model/parse`:
   - Purpose: NLU parsing
   - Method: POST
   - Body: `{ text: string }`

### Architecture

```mermaid
graph TD
    A[Frontend] --> B[Supabase Edge Functions]
    B --> C[Rasa Pro]
    B --> D[CALM]
    C --> E[Actions Server]
    E --> F[Database]
    D --> F
```

### Error Recovery

The system implements a robust error recovery strategy:

1. Rasa Pro Connection:
   - Health checks every 30 seconds
   - Automatic retry with exponential backoff
   - Fallback to OpenAI for complex queries

2. Database Operations:
   - Optimistic updates with rollback
   - Real-time sync recovery
   - Offline support with local storage

3. Edge Functions:
   - Circuit breaker pattern
   - Request timeout handling
   - Automatic retries

### Demo Access

Try the demo with these credentials:
- Email: demo@example.com
- Password: demo123456

### Built With

- Rasa Pro + CALM
- Supabase
- React
- TypeScript
- Tailwind CSS

### License

© 2024 ViLa Ventures. All rights reserved.
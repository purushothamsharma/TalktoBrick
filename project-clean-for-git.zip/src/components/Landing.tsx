// Previous content replaced with updated branding
// See full file content above in the conversation history